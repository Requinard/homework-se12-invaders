﻿namespace SE12Invaders
{
    partial class InvadersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InvadersForm));
            this.gbVeld = new System.Windows.Forms.GroupBox();
            this.pbAfbeelding6 = new System.Windows.Forms.PictureBox();
            this.pbAfbeelding5 = new System.Windows.Forms.PictureBox();
            this.pbAfbeelding4 = new System.Windows.Forms.PictureBox();
            this.pbAfbeelding3 = new System.Windows.Forms.PictureBox();
            this.pbAfbeelding2 = new System.Windows.Forms.PictureBox();
            this.pbAfbeelding1 = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.gbInstellingen = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nudAantalSteden = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nudInvaderSnelheid = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nudInvaderLevens = new System.Windows.Forms.NumericUpDown();
            this.btnStart = new System.Windows.Forms.Button();
            this.gbSpelstatus = new System.Windows.Forms.GroupBox();
            this.lblAantalInvaders = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblAantalSteden = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gbVeld.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding1)).BeginInit();
            this.gbInstellingen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAantalSteden)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudInvaderSnelheid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudInvaderLevens)).BeginInit();
            this.gbSpelstatus.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbVeld
            // 
            this.gbVeld.Controls.Add(this.pbAfbeelding6);
            this.gbVeld.Controls.Add(this.pbAfbeelding5);
            this.gbVeld.Controls.Add(this.pbAfbeelding4);
            this.gbVeld.Controls.Add(this.pbAfbeelding3);
            this.gbVeld.Controls.Add(this.pbAfbeelding2);
            this.gbVeld.Controls.Add(this.pbAfbeelding1);
            this.gbVeld.Location = new System.Drawing.Point(12, 12);
            this.gbVeld.Name = "gbVeld";
            this.gbVeld.Size = new System.Drawing.Size(340, 300);
            this.gbVeld.TabIndex = 0;
            this.gbVeld.TabStop = false;
            // 
            // pbAfbeelding6
            // 
            this.pbAfbeelding6.Image = ((System.Drawing.Image)(resources.GetObject("pbAfbeelding6.Image")));
            this.pbAfbeelding6.Location = new System.Drawing.Point(285, 7);
            this.pbAfbeelding6.Name = "pbAfbeelding6";
            this.pbAfbeelding6.Size = new System.Drawing.Size(50, 46);
            this.pbAfbeelding6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbAfbeelding6.TabIndex = 5;
            this.pbAfbeelding6.TabStop = false;
            this.pbAfbeelding6.Visible = false;
            this.pbAfbeelding6.Click += new System.EventHandler(this.pbAfbeelding6_Click);
            // 
            // pbAfbeelding5
            // 
            this.pbAfbeelding5.Image = ((System.Drawing.Image)(resources.GetObject("pbAfbeelding5.Image")));
            this.pbAfbeelding5.Location = new System.Drawing.Point(229, 7);
            this.pbAfbeelding5.Name = "pbAfbeelding5";
            this.pbAfbeelding5.Size = new System.Drawing.Size(50, 46);
            this.pbAfbeelding5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbAfbeelding5.TabIndex = 4;
            this.pbAfbeelding5.TabStop = false;
            this.pbAfbeelding5.Visible = false;
            this.pbAfbeelding5.Click += new System.EventHandler(this.pbAfbeelding5_Click);
            // 
            // pbAfbeelding4
            // 
            this.pbAfbeelding4.Image = ((System.Drawing.Image)(resources.GetObject("pbAfbeelding4.Image")));
            this.pbAfbeelding4.Location = new System.Drawing.Point(173, 7);
            this.pbAfbeelding4.Name = "pbAfbeelding4";
            this.pbAfbeelding4.Size = new System.Drawing.Size(50, 46);
            this.pbAfbeelding4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbAfbeelding4.TabIndex = 3;
            this.pbAfbeelding4.TabStop = false;
            this.pbAfbeelding4.Visible = false;
            this.pbAfbeelding4.Click += new System.EventHandler(this.pbAfbeelding4_Click);
            // 
            // pbAfbeelding3
            // 
            this.pbAfbeelding3.Image = ((System.Drawing.Image)(resources.GetObject("pbAfbeelding3.Image")));
            this.pbAfbeelding3.Location = new System.Drawing.Point(117, 7);
            this.pbAfbeelding3.Name = "pbAfbeelding3";
            this.pbAfbeelding3.Size = new System.Drawing.Size(50, 46);
            this.pbAfbeelding3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbAfbeelding3.TabIndex = 2;
            this.pbAfbeelding3.TabStop = false;
            this.pbAfbeelding3.Visible = false;
            this.pbAfbeelding3.Click += new System.EventHandler(this.pbAfbeelding3_Click);
            // 
            // pbAfbeelding2
            // 
            this.pbAfbeelding2.Image = ((System.Drawing.Image)(resources.GetObject("pbAfbeelding2.Image")));
            this.pbAfbeelding2.Location = new System.Drawing.Point(61, 7);
            this.pbAfbeelding2.Name = "pbAfbeelding2";
            this.pbAfbeelding2.Size = new System.Drawing.Size(50, 46);
            this.pbAfbeelding2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbAfbeelding2.TabIndex = 1;
            this.pbAfbeelding2.TabStop = false;
            this.pbAfbeelding2.Visible = false;
            this.pbAfbeelding2.Click += new System.EventHandler(this.pbAfbeelding2_Click);
            // 
            // pbAfbeelding1
            // 
            this.pbAfbeelding1.Image = ((System.Drawing.Image)(resources.GetObject("pbAfbeelding1.Image")));
            this.pbAfbeelding1.Location = new System.Drawing.Point(5, 7);
            this.pbAfbeelding1.Name = "pbAfbeelding1";
            this.pbAfbeelding1.Size = new System.Drawing.Size(50, 46);
            this.pbAfbeelding1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbAfbeelding1.TabIndex = 0;
            this.pbAfbeelding1.TabStop = false;
            this.pbAfbeelding1.Visible = false;
            this.pbAfbeelding1.Click += new System.EventHandler(this.pbAfbeelding1_Click);
            // 
            // timer
            // 
            this.timer.Interval = 150;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // gbInstellingen
            // 
            this.gbInstellingen.Controls.Add(this.label4);
            this.gbInstellingen.Controls.Add(this.nudAantalSteden);
            this.gbInstellingen.Controls.Add(this.label3);
            this.gbInstellingen.Controls.Add(this.nudInvaderSnelheid);
            this.gbInstellingen.Controls.Add(this.label2);
            this.gbInstellingen.Controls.Add(this.nudInvaderLevens);
            this.gbInstellingen.Controls.Add(this.btnStart);
            this.gbInstellingen.Location = new System.Drawing.Point(358, 19);
            this.gbInstellingen.Name = "gbInstellingen";
            this.gbInstellingen.Size = new System.Drawing.Size(263, 137);
            this.gbInstellingen.TabIndex = 10;
            this.gbInstellingen.TabStop = false;
            this.gbInstellingen.Text = "Instellingen";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Aantal steden";
            // 
            // nudAantalSteden
            // 
            this.nudAantalSteden.Location = new System.Drawing.Point(97, 31);
            this.nudAantalSteden.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nudAantalSteden.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudAantalSteden.Name = "nudAantalSteden";
            this.nudAantalSteden.Size = new System.Drawing.Size(59, 20);
            this.nudAantalSteden.TabIndex = 15;
            this.nudAantalSteden.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Invader-snelheid";
            // 
            // nudInvaderSnelheid
            // 
            this.nudInvaderSnelheid.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudInvaderSnelheid.Location = new System.Drawing.Point(97, 92);
            this.nudInvaderSnelheid.Maximum = new decimal(new int[] {
            25,
            0,
            0,
            0});
            this.nudInvaderSnelheid.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudInvaderSnelheid.Name = "nudInvaderSnelheid";
            this.nudInvaderSnelheid.Size = new System.Drawing.Size(59, 20);
            this.nudInvaderSnelheid.TabIndex = 13;
            this.nudInvaderSnelheid.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Invader-levens";
            // 
            // nudInvaderLevens
            // 
            this.nudInvaderLevens.Location = new System.Drawing.Point(97, 60);
            this.nudInvaderLevens.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nudInvaderLevens.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudInvaderLevens.Name = "nudInvaderLevens";
            this.nudInvaderLevens.Size = new System.Drawing.Size(59, 20);
            this.nudInvaderLevens.TabIndex = 11;
            this.nudInvaderLevens.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(173, 31);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(77, 81);
            this.btnStart.TabIndex = 10;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // gbSpelstatus
            // 
            this.gbSpelstatus.Controls.Add(this.lblAantalInvaders);
            this.gbSpelstatus.Controls.Add(this.label5);
            this.gbSpelstatus.Controls.Add(this.lblAantalSteden);
            this.gbSpelstatus.Controls.Add(this.label1);
            this.gbSpelstatus.Location = new System.Drawing.Point(358, 160);
            this.gbSpelstatus.Name = "gbSpelstatus";
            this.gbSpelstatus.Size = new System.Drawing.Size(263, 150);
            this.gbSpelstatus.TabIndex = 11;
            this.gbSpelstatus.TabStop = false;
            this.gbSpelstatus.Text = "Spelstatus";
            // 
            // lblAantalInvaders
            // 
            this.lblAantalInvaders.AutoSize = true;
            this.lblAantalInvaders.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAantalInvaders.Location = new System.Drawing.Point(169, 47);
            this.lblAantalInvaders.Name = "lblAantalInvaders";
            this.lblAantalInvaders.Size = new System.Drawing.Size(0, 24);
            this.lblAantalInvaders.TabIndex = 7;
            this.lblAantalInvaders.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 24);
            this.label5.TabIndex = 6;
            this.label5.Text = "Aantal invaders:";
            // 
            // lblAantalSteden
            // 
            this.lblAantalSteden.AutoSize = true;
            this.lblAantalSteden.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAantalSteden.Location = new System.Drawing.Point(169, 94);
            this.lblAantalSteden.Name = "lblAantalSteden";
            this.lblAantalSteden.Size = new System.Drawing.Size(0, 24);
            this.lblAantalSteden.TabIndex = 5;
            this.lblAantalSteden.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Aantal steden:";
            // 
            // InvadersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 322);
            this.Controls.Add(this.gbSpelstatus);
            this.Controls.Add(this.gbInstellingen);
            this.Controls.Add(this.gbVeld);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InvadersForm";
            this.Text = "Invaders!!";
            this.gbVeld.ResumeLayout(false);
            this.gbVeld.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAfbeelding1)).EndInit();
            this.gbInstellingen.ResumeLayout(false);
            this.gbInstellingen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAantalSteden)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudInvaderSnelheid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudInvaderLevens)).EndInit();
            this.gbSpelstatus.ResumeLayout(false);
            this.gbSpelstatus.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbVeld;
        private System.Windows.Forms.PictureBox pbAfbeelding2;
        private System.Windows.Forms.PictureBox pbAfbeelding1;
        private System.Windows.Forms.PictureBox pbAfbeelding6;
        private System.Windows.Forms.PictureBox pbAfbeelding5;
        private System.Windows.Forms.PictureBox pbAfbeelding4;
        private System.Windows.Forms.PictureBox pbAfbeelding3;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.GroupBox gbInstellingen;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudAantalSteden;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudInvaderSnelheid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nudInvaderLevens;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.GroupBox gbSpelstatus;
        private System.Windows.Forms.Label lblAantalInvaders;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblAantalSteden;
        private System.Windows.Forms.Label label1;
    }
}

